from django.apps import AppConfig


class Account3Config(AppConfig):
    name = 'account3'
